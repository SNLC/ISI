function nr = getnoreps(c)

global looperInfo

nr = length(looperInfo.conds{c}.repeats);