function ttag = gettrialno(c,r)

global looperInfo

trialno = looperInfo.conds{c}.repeats{r}.trialno;
