function nc = getnoconds


global looperInfo

nc = length(looperInfo.conds);