figure, 
imagesc(grab.img)
colormap gray